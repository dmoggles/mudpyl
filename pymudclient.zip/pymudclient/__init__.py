"""pymudclient is a MUD client written in Python, designed to have a simple core
and be extensible.
"""

__version__ = '0.2.0'
