'''
Created on Jul 16, 2015

@author: Dmitry
'''

class MyClass(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        