"""A collection of reusable scripts for users."""
