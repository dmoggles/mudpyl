"""Modules specific to Imperian (imperian.com).

General IRE modules and modules for other IRE games may also work.
"""
