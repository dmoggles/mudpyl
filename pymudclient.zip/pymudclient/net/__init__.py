"""The interface to the internet. Contains a very poor telnet implementation,
an MCCP v2 client, and a doesn't-even-try-to-be-complete VT100 emulator.
"""
